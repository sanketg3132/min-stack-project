import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from '@angular/forms';

import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  constructor(private router: Router,private fb: FormBuilder,private http:HttpClient) { }

  ngOnInit(): void {
  }

  registerdata= this.fb.group({
    FristName: ['',[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    LastName: ['', [Validators.required,Validators.pattern('[a-zA-Z]*')]],
    username:['',Validators.required],
    Password:['',Validators.required],
    NewPassword:['',Validators.required]
  });
  
  async loginhere()
  {
     const data=this.registerdata.value
     if(this.registerdata.value.Password===this.registerdata.value.NewPassword)
     {
      const url="http://localhost:8000/adduser"
      let done= await this.http.post(url,data).toPromise();
      this.router.navigate(['login'])
     }
     else
     {
        alert("plases enter matcing password")
     }  
  }
}
