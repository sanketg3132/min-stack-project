import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  show:boolean=false
  constructor(private router: Router,private fb: FormBuilder,private http:HttpClient) { }

  ngOnInit(): void {
  }
    
  forgotdata= this.fb.group({
    username: ['', Validators.required],
    NewPassword: ['', Validators.required],
    ConfromNewPassword: ['', Validators.required]
  });
  
  async backtologin(page)
  {
    
    if(this.forgotdata.value.NewPassword===this.forgotdata.value.ConfromNewPassword)
    {
        const forgotpasswordjson=this.forgotdata.value
        const url="http://localhost:8000/forgotpassword"
        let done: any= await this.http.post(url,forgotpasswordjson).toPromise();
        if(done.massage==="Success")
        {
          this.router.navigate([page]);
        }
        else
        {
          this.show=true
        }
    }
    else
    {
        alert("plases enter matcing password")
        this.forgotdata.reset()
    }
  }
}
