import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
@Component({
  selector: 'app-page3',
  templateUrl: './page3.component.html',
  styleUrls: ['./page3.component.css']
})
export class Page3Component implements OnInit {
  constructor(private fb: FormBuilder,private http:HttpClient,private router: Router) {}

  sanket = this.fb.group({
    FristName: ['', Validators.required],
    LastName: ['', Validators.required],
    Email: ['', Validators.required],
    Birthdate: ['', Validators.required],
    SchoolName: ['', Validators.required],
    CollageName: ['', Validators.required],
    FevoriteFood: ['', Validators.required],
    CloseFriends: ['', Validators.required],
    Relationship: ['', Validators.required],
    FevoritePlaces: ['', Validators.required],
    Address:['', Validators.required],
    City:['', Validators.required],
    state:['', Validators.required],
    Mobileno:['', Validators.required],
  });
  async dataupdate()
  {
        const data=this.sanket.value
        console.log(data)
        const url="http://localhost:8000/update"
        await this.http.post(url, data).toPromise();
  }
  ngOnInit(): void {
  }
  change(page)
  {
    this.router.navigate([page]);
  }
}
