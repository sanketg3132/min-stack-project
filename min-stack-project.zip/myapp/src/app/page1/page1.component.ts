import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from '@angular/forms';
import { NgbActiveModal,NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ShowprofileComponent } from '../showprofile/showprofile.component';
@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit {
  public data:any={}
  public data2:any=[]
  isno:boolean=true
  d:boolean=false
  s:boolean=false
  constructor(private router: Router,private http:HttpClient,private fb: FormBuilder,private modalService:NgbModal ) { }
  
  ngOnInit(): void {
     this.load()
     this.load2()
    if (!sessionStorage.getItem('sid')){
      this.router.navigate(['login']);
    }
  }

  public user:any=sessionStorage.getItem('sid')
  sanket = this.fb.group({
    username:this.user,
    FristName: ["",[Validators.pattern('[a-zA-Z]*')]],
    LastName: ["",[Validators.pattern('[a-zA-Z]*')]],
    Email: ["",[Validators.required,Validators.email]],
    Birthdate: ["",Validators.required],
    SchoolName: ["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    CollageName: ["", [Validators.required,Validators.pattern('[a-zA-Z]*')]],
    FevoriteFood: ["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    CloseFriends: ["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    Relationship: ["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    FevoritePlaces: ["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    Address:["", [Validators.required,Validators.pattern('[a-zA-Z0-9]*'),Validators.minLength(5)]],
    City:["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    state:["",[Validators.required,Validators.pattern('[a-zA-Z]*')]],
    Mobileno:["", [Validators.required,Validators.pattern('[0-9]*'),Validators.minLength(10)]],
  });
  async load2()
  {
    let sid=sessionStorage.getItem('sid')
    let jj=
    {
       user:sid
    }
    const url="http://localhost:8000/getdata"
    let done:any=await this.http.post(url,jj).toPromise();
     this.data2=done
  }
  async dataupdate()
  {
          const data=this.sanket.value
          if(this.sanket.value.FristName!='' && this.sanket.value.LastName!='' 
          && this.sanket.value.Email!='' && this.sanket.value.Birthdate!='' 
          && this.sanket.value.SchoolName!='' && this.sanket.value.FevoriteFood!=''
          && this.sanket.value.CloseFriends!='' && this.sanket.value.Relationship!=''
          && this.sanket.value.FevoritePlaces!='' && this.sanket.value.Address!=''
          && this.sanket.value.City!='' && this.sanket.value.state!=''
          && this.sanket.value.Mobileno!='')
          {
              const url="http://localhost:8000/update"
              let done:any=await this.http.post(url, data).toPromise();
              if(done.massage==="Success")
              {
                  alert("data is successfully edited");
                  this.sanket.reset();
              }
          }
          else
          {
            alert("cant update empty filed");
          }
        
  }
  
  gotohome()
  {
      this.isno=true
      this.s=false
      this.d=false
  }
  async gotoprofile()
  {
      this.isno=false
      this.d=true
      this.s=false
      let sid=sessionStorage.getItem('sid')
    let jj=
    {
       user:sid
    }
    const url="http://localhost:8000/name"
     let done: any= await this.http.post(url,jj).toPromise();
     this.data=done
  }
  gotoeditprofile()
  {
      this.isno=false
      this.d=false
      this.s=true
  }
  logout()
  {
       sessionStorage.removeItem('sid')
       this.router.navigate(['login'])
  }
  async load()
  {
    let sid=sessionStorage.getItem('sid')
    let jj=
    {
       user:sid
    }
    const url="http://localhost:8000/name"
     let done: any= await this.http.post(url,jj).toPromise();
     this.data=done
  }
 
  change(page)
  {
    this.router.navigate([page]);
  }

  openprofile(item)
  {
    const modalRef=this.modalService.open(ShowprofileComponent, {
      centered: true,
    })
    modalRef.componentInstance.data = item;
  }

}
