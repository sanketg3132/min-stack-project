import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  d:boolean=false
  constructor(private router: Router,private fb: FormBuilder,private http:HttpClient) { }

  logindata = this.fb.group({
    username: ['', Validators.required],
    Password: ['', Validators.required]
  });
  
  async loginhere()
  {
     const login=this.logindata.value
    // console.log(login)
     const url="http://localhost:8000/login"
     let done: any= await this.http.post(url,login).toPromise();
     //console.log(done)
     if(done.massage==="Success")
     {
         sessionStorage.setItem('sid',login.username);
         this.router.navigate(['page1']);
     }
     else
     {
           this.d=true
     }
     
  }
  ngOnInit(): void {
  }
  rgister(page)
  {
    this.router.navigate([page]);
  }
  gotoforgot(page)
  {
    this.router.navigate([page]);
  }
}
